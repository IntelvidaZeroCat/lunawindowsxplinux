-----------------------
Linux Luna XP Theme
-----------------------
Last Updated: 3/23/2018
www.winxp4life.tk

Changes:
	-  Fixed some taskbar (AKA PanelToplevel.background in Linux) background issues 
	-  Cleaned up a lot of menubar related issues.
	-  Cleaned up some primary-toolbar, headerbar, and titlebar issues.
	-  Added better XP like scroll bars.
	-  Rewrote lots of sections to be compatible with GTK 3.20+
	-  Fixed consistency issues.
	-  Missing system icons added.
	-  Fixed window resizing issue. 
	-  Icon set now inherits from MATE
	-  This version works for Ubuntu 16.10+

-----------
Prerequisites:
-----------

GNOME2 or MATE Desktop Environment (Compatible with both GTK2 and GTK3)

MATE install Guide for Ubuntu:  http://www.tecmint.com/install-mate-desktop-in-ubuntu-fedora/

-----------
To install:
-----------

The below instructions assume you have MATE or GNOME2 installed.

1. Run the install.sh script to make the Luna theme available to all users (requires sudo access). Or, run the install_local_user.sh to install the Luna theme for the current user only (sudo access NOT required).

2. After the install script exits, right click on your desktop and choose "Change Desktop Background".

3. If you want to use the default XP background, select the "luna_background.jpg" file located in your ~/Pictures directory.

4. Then click on the "Themes" tab and select "Luna"

The theme has been successfully installed.

-----------
Tested In:
-----------

Ubuntu 17.10 running MATE 1.18.0

-----------
Credits:
-----------

Conversion to GTK3 by own3mall
Luna Theme Originally By: Casey Kirsle
Updated Version Originally Released:  4/15/2013
