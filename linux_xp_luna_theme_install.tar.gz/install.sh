#!/bin/bash
# Installs the XP Luna Theme for MATE GTK3
clear

#######################
#      Functions      #
#######################

function isPackageInstalledDEB(){
	# $1 is the name of the package to check if it's installed
	isInDPKGDatabase=$(dpkg-query -l "$1" 2>&1 | grep -o "no packages")
	if [ -z "$isInDPKGDatabase" ]; then
		# The package was found, so now we have to check its status
		packageStatus=$(dpkg-query -l "$1" | tail -n 1 | awk '{print $1}')
		secondLetterOfPackageStatus=${packageStatus:1:1}
		secondLetterOfPackageStatus=$(echo "$secondLetterOfPackageStatus" | awk '{print tolower($0)}')
		if [ "$secondLetterOfPackageStatus" != "i" ]; then
			# Package is in a state of removed, but configuration files may still exist... 
			# let's treat this as not being installed
			return 1 # 1 is false in bash
		else
			# Package is installed and is not in a removed state
			return 0 # 0 is true in bash
		fi
	else
		# The package was not found so return false
		return 1 # 1 is false in bash
	fi
}

function isPackageInstalledRED(){
	# $1 is the name of the package to check if it's installed
	isInstalledYUM=$(rpm -q "$1" | grep -o "not installed")
	if [ -z "$isInstalledYUM" ]; then
		# Package is installed
		return 0 # 0 is true in bash
	else
		return 1 # 1 is false in bas
	fi
}

function isSoftwarePackageInstalled(){
	# $1 is the name of the package to check if it's installed
	if [ ! -z "$1" ]; then	
		# For debian based OS'
		hasDPKG=$(which dpkg 2>/dev/null)
		if [ ! -z "$hasDPKG" ] || [ -e "/usr/bin/dpkg" ]; then
			packageManager="deb"
			# DPKG exists!  That means we can query for packages
			return $(isPackageInstalledDEB "$1")
		fi
		
		# For redhat based OS'		
		hasYUM=$(which yum 2>/dev/null)
		hasRPM=$(which rpm 2>/dev/null)
		if [ ! -z "$hasYUM" ] || [ ! -z "$hasRPM" ] || [ -e "/usr/bin/yum" ] || [ -e "/usr/bin/rpm" ]; then
			packageManager="yum"
			# DPKG exists!  That means we can query for packages
			return $(isPackageInstalledRED "$1")
		fi
	fi
	
	# Default is to return false
	return 1
}

function removePackage(){
	# $1 is the package name to remove
	if [ ! -z "$1" ] && [ ! -z "$packageManager" ]; then
		if [ "$packageManager" == "deb" ]; then
			apt-get -y -q remove "$1"
		fi
		if [ "$packageManager" == "yum" ]; then
			yum -y remove "$1"
		fi
	fi
}

function installPackage(){
	# $1 is the package name to remove
	if [ ! -z "$1" ] && [ ! -z "$packageManager" ]; then
		if [ "$packageManager" == "deb" ]; then
			apt-get -y -q install "$1"
		fi
		if [ "$packageManager" == "yum" ]; then
			yum -y -q install epel-release
			yum -y install "$1"
		fi
	fi
}

function rootCheck(){ # Make sure this script is run with sudo
	if [ "$(id -u)" != "0" ]; then
		echo -e "Please run this script by using sudo or root access to make the Luna theme available to all users on this system!\n" 1>&2
		echo -n "Would you like to install the theme locally? [y/n]: "
		read localModeIns
		localModeIns=$(echo "$localModeIns" | awk '{print tolower($0)}')
		
		if [ "$localModeIns" != "n" ]; then
			bash install_local_user.sh
		fi
		exit
	fi
}

function removeOverlayScrollbars(){
	numInvalidPackagesInstalled=0
	packagesToRemoveIfInstalled=('overlay-scrollbar' 'liboverlay-scrollbar3' 'liboverlay-scrollbar')
	for i in ${packagesToRemoveIfInstalled[@]}; do
		if isSoftwarePackageInstalled "$i"; then
			numInvalidPackagesInstalled=$((numInvalidPackagesInstalled+1))
		fi
	done
	
	if [ "$numInvalidPackagesInstalled" -gt "0" ]; then
		echo -e ""
		echo -n "Would you like to uninstall the overlay scrollbar packages to make this theme look better? [y/n]: "
		read insMode
		insMode=$(echo "$insMode" | awk '{print tolower($0)}')
		if [ "$insMode" != "n" ]; then
			removePackages="YES"
		fi
	fi
		
	if [ "$removePackages" == "YES" ]; then
		echo -e "\nUninstalling overlay packages..."
		for i in ${packagesToRemoveIfInstalled[@]}; do
			removePackage "$i"
		done
			
		echo -e ""
		echo -n "Your computer needs to be restarted before the overlay scrollbar changes will apply. Restart now? [y/n]: "
		read insMode
		insMode=$(echo "$insMode" | awk '{print tolower($0)}')
		if [ "$insMode" != "n" ]; then
			shutdown -r now
		fi
	fi
	
}

#######################
#       App Code      #
#######################
rootCheck

echo -e "--------------------\nLinux Luna XP Theme\n--------------------\nLast Updated: 3/23/2018\nwww.winxp4life.tk\nFor MATE 1.12+ / Ubuntu 17.10, Debian 9, and Greater\nCompatible with GTK 3.20+\n"
echo -e "\nInstalling Luna Theme..."

# First uninstall existing theme if it exists
if [ -e "/usr/share/themes/Luna" ]; then
	echo -e "Detected a previous version of the Luna theme... uninstalling..."
	rm -rf "/usr/share/themes/Luna"
	rm -rf "/usr/share/icons/Luna"
fi

# Copy theme files
echo -e "Copying and installing Luna theme files..."
cp -r themes /usr/share/
cp -r icons /usr/share/

# Fix perms on theme files
chown root:root -R /usr/share/themes
chown root:root -R /usr/share/icons
chmod 755 -R /usr/share/themes/Luna
chmod 755 -R /usr/share/icons/Luna

# Copy luna background to the user using sudo picture directory
if [ ! -z "$SUDO_USER" ]; then
	if [ -e "/home/$SUDO_USER" ]; then
		if [ ! -e "/home/$SUDO_USER/Pictures" ]; then
			mkdir -p "/home/$SUDO_USER/Pictures"
		fi
		cp luna_background.jpg "/home/$SUDO_USER/Pictures"
	fi
fi

# Copy luna background to root user picture directory
if [ ! -d ~/Pictures ];
then
	mkdir ~/Pictures
fi

cp luna_background.jpg ~/Pictures

# Echo out

echo -e "\nSuccessfully copied the Luna theme files to the proper directories!"
echo -e
echo -e "The Luna default desktop wallpaper is located in your Pictures directory."
echo -e
echo -e "To install this theme and wallpaper, Right Click on your desktop and choose \"Change Desktop Background\""
echo -e
echo -e "Choose your Wallpaper image, then click on the Themes tab and select \"Luna\""
removeOverlayScrollbars
