#!/bin/bash
# Installs the XP Luna Theme for Ubuntu
clear

# Show welcome splash
echo -e "--------------------\nLinux Luna XP Theme\n--------------------\nLast Updated: 3/23/2018\nwww.winxp4life.tk\nFor MATE 1.12+ / Ubuntu 17.10, Debian 9, and Greater\nCompatible with GTK 3.20+\n"
echo -e "\nInstalling Luna Theme..."

# Make the directories
mkdir -p ~/.themes/Luna
mkdir -p ~/.icons/Luna

# First uninstall existing theme if it exists
if [ -e "~/.themes/Luna" ]; then
	echo -e "Detected a previous version of the Luna theme... uninstalling..."
	rm -rf "~/.themes/Luna"
	rm -rf "~/.icons/Luna"
fi

# Copy the actual theme files
echo -e "Copying and installing Luna theme files..."
cp -r themes/Luna/* ~/.themes/Luna
cp -r icons/Luna/* ~/.icons/Luna

# Worry about XP background
if [ ! -d ~/Pictures ];
then
	mkdir ~/Pictures
fi
cp luna_background.jpg ~/Pictures

echo -e "\nSuccessfully copied the Luna theme files to the proper directories!"
echo -e
echo -e "The Luna default desktop wallpaper is located in your Pictures directory."
echo -e
echo -e "To install this theme and wallpaper, Right Click on your desktop and choose \"Change Desktop Background\""
echo -e
echo -e "Choose your Wallpaper image, then click on the Themes tab and select \"Luna\""
echo -e
echo -e "If you notice any problems with this theme, ask an admin with sudo access to remove the overlay-scrollbar package.  It causes a few minor bugs."
